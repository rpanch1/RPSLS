import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;

public class RunningController 
{
	//load in the elements from the fxml file
	@FXML
	Label clientCount;
	@FXML 
	Label gameCount;
	@FXML
	ListView<String> clientList;
	@FXML
	ListView<String> serverLog;
	@FXML
	Label addressLabel;
	
}
