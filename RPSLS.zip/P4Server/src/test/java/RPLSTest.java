import static org.junit.jupiter.api.Assertions.*;
import java.io.Serializable;
import java.util.function.Consumer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class RPLSTest 
{

	RPSLSServer server;
	
	@BeforeEach
	void setup()
	{
		
		Consumer<Serializable> fail = data -> {
			
			System.out.println("failed connection");
			
		};
		
		Consumer<Serializable> success = data -> {
			
			System.out.println("successful connection");
			
		};
		
		Consumer<Serializable> gui = data -> {
			
			System.out.println("gui update");
			
		};
		
		Consumer<String> list = data -> {
			
			System.out.println("list update");
			
		};
		
		//create a new dummy server before each test, using localhost ip and port 5555 for testing purposes
		server = new RPSLSServer(success, fail, gui, list, 5555);
	}
	
	@Test
	void testServerInit() 
	{
		assertEquals("RPSLSServer", server.getClass().getName(), "server not initialized properly");
	}

}
