import static org.junit.jupiter.api.Assertions.*;
import java.io.Serializable;
import java.util.function.Consumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

class RPLSTest 
{

	RPSLSClient client;
	
	@BeforeEach
	void setup()
	{
		
		Consumer<Serializable> fail = data -> {
			
			System.out.println("failed connection");
			
		};
		
		Consumer<Serializable> success = data -> {
			
			System.out.println("successful connection");
			
		};
		
		Consumer<Serializable> gui = data -> {
			
			System.out.println("gui update");
			
		};
		
		Consumer<String> list = data -> {
			
			System.out.println("list update");
			
		};
		
		//create a new client before each test, using localhost ip and port 5555 for testing purposes
		client = new RPSLSClient(success, fail, gui, gui, gui, list, "127.0.0.1", 5555);
	}
	
	@Test
	void testClientInit() 
	{
		assertEquals("RPSLSClient", client.getClass().getName(), "client not initialized properly");
	}

}
