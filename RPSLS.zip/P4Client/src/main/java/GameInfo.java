import java.io.Serializable;
import java.util.HashMap;

public class GameInfo implements Serializable
{
	private static final long serialVersionUID = 6881001335554348969L;
	GameInfo(HashMap<Integer, Integer> cl, int p1n, int p2n, String p1pl, String p2pl, Boolean br)
	{
		clients = cl;
		
		p1Num = p1n;
		p2Num = p2n;
		
		p1Play = p1pl;
		p2Play = p2pl;
		
		bothReady = br;
		
		winner = "none";
		
		chal = 0;
	}
	
	//the key is the number id of the client, the value is -1 if not connected,
	//0 if connected and not in game, and otherwise its the number id of 
	//the player their in a game with
	HashMap<Integer, Integer> clients;
	
	int p1Num;
	int p2Num;
	String p1Play;
	String p2Play;
	Boolean bothReady;
	String winner;
	int chal;
}
