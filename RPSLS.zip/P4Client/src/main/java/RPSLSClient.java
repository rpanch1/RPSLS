import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.function.Consumer;

public class RPSLSClient extends Thread
{
	Socket socketClient;
	
	ObjectOutputStream out;
	ObjectInputStream in;
	
	//client identification number provided by the server
	int myNumber;
	
	//ip address and port to be set by user
	String ipAddress;
	int portNumber;
	
	//client side instance of gameinfo to store most recent info received from server
	GameInfo gameInfo;
	
	//consumer to update the gui with new game information
	private Consumer<Serializable> playGuiUpdate;
	private Consumer<Serializable> chooseGuiUpdate;
	
	//consumer to show a challenged popup when player is challenged
	private Consumer<Serializable> challenged;
	
	//consumers with runnables for updating the gui based on connection outcome
	private Consumer<Serializable> successRun;
	private Consumer<Serializable> failRun;
	
	RPSLSClient(Consumer<Serializable> success, Consumer<Serializable> fail, Consumer<Serializable> playgui, Consumer<Serializable> choosegui, Consumer<Serializable> chal, Consumer<String> list, String ip, int port)
	{
		ipAddress = ip;
		portNumber = port;
		successRun = success;
		failRun = fail;
		playGuiUpdate = playgui;
		chooseGuiUpdate = choosegui;
		challenged = chal;
	}
	
	public void run()
	{
		
		try 
		{
			//create connection to server
			socketClient= new Socket(ipAddress, portNumber);
			out = new ObjectOutputStream(socketClient.getOutputStream());
			in = new ObjectInputStream(socketClient.getInputStream());
			socketClient.setTcpNoDelay(true);
			
			//run the consumer runnable to update gui for a successful connection
			successRun.accept(1);
			
		}
		catch(Exception e) 
		{
			//update gui for failed connection if there was an exception
			failRun.accept(1);
		}
		
		while(true) 
		{
		
			try 
			{	
				//read in the current game information form the server
				GameInfo gi = (GameInfo) in.readObject();
				
				gameInfo = gi; //update gameInfo to most recent from server to be accessed elsewhere
				
				//if p1Num is -5, then my number assigment is in p2Num
				if(gi.p1Num == -5)
				{
					//assign p2Num as the id to this client
					myNumber = gi.p2Num;
					
					//update the gui with the info in gi
					chooseGuiUpdate.accept(gi);
				}
				
				//if both p1Num and p2Num are 0, then read in the object to update clientList
				else if(gi.p1Num == 0 && gi.p2Num == 0)
				{	
					chooseGuiUpdate.accept(gi);
				}

				//if the challenge int is not 0, send it to be handled by controller
				if(gi.chal > 0)
				{
					//update the gui based on outcome of challenge request
					challenged.accept(gi);
				}
	
				//if this client is in a game, we only care about the game info addressed to us
				if(gameInfo.clients.get(myNumber) > 0 && (gi.p1Num == myNumber || gi.p2Num == myNumber))
				{			
					//update the gameplay gui with new game information
					playGuiUpdate.accept(gi);
				}
			}
			catch(Exception e){}
		}
	
    }
	
	public void send(GameInfo gi) 
	{
		try 
		{
			out.writeObject(gi);
			out.reset();
			
			//update calling clients own gui as well
			playGuiUpdate.accept(gi);
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}


}
