import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.util.function.Consumer;
import java.io.Serializable;
import java.util.ArrayList;

public class ConnectSceneController
{
	RPSLSClient clientConnection;
	Scene playScene;
	Scene chooseScene;
	
	//controller so that first scene controller can access second scene
	PlaySceneController playController;
	
	//controller so that connect scene can access choose screen 
	ChooseSceneController chooseController;
	
	GameInfo gi;
	
	//ImageViews for each of the icons
	Image unknown = new Image("/unknown.png");
	Image notConnected = new Image("/notConnected.png");
	
	//retrieve the gui elements from start scene fxml file
	@FXML
	TextField ipField;
	@FXML
	TextField portField;
	@FXML
	Button connectBtn;
	@FXML
	Label errorLabel;
    
    ConnectSceneController()
    {    	
    }
    
    
	public void handleConnectButton()
	{	
		//load other scenes in case of a successful connect
		try
		{
			//load client choose scene
			FXMLLoader loader1 = new FXMLLoader(getClass().getResource("/fxml/clientChooseScene.fxml"));
			loader1.setController(new ChooseSceneController());
			chooseScene = new Scene(loader1.load(), 800, 550);
			
			//get the controller from the second scene
			chooseController = loader1.getController();
			chooseController.connectController = this;
			
			chooseController.addressLabel.setText("connected to: " + ipField.getText() + ":" + Integer.parseInt(portField.getText()));
			
			//load the client playing scene
			FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/fxml/clientRunningScene.fxml"));
			loader2.setController(new PlaySceneController());
			playScene = new Scene(loader2.load(), 800, 550);
			
			//get the controller for the third scene
			playController = loader2.getController();
			playController.connectController = this;
		}
		catch(Exception e) 
		{
			System.out.println("could not load fxml file: " + e);
		}
		
		//create a pause transition for when a connection is successful
		PauseTransition successfulConnect = new PauseTransition(Duration.seconds(2));
		successfulConnect.setOnFinished(event -> {
			
			//set scene to choose scene
	    	Stage primaryStage = (Stage) connectBtn.getScene().getWindow();
	    	primaryStage.setScene(chooseScene);
			
		});
		
		//create a pause transition for when a connection is unsuccessful
		PauseTransition failedConnect = new PauseTransition(Duration.seconds(3));
		failedConnect.setOnFinished(event -> {errorLabel.setText("");});
		
		PauseTransition gameover = new PauseTransition(Duration.seconds(3));
		gameover.setOnFinished(event -> {
			
			//have player 1 send a client status update to the server so other players know that
			//the game is over
			if(clientConnection.myNumber == gi.p1Num)
			{
				//indicate players are now waiting for game with 0's
				gi.clients.put(gi.p1Num, 0);
				gi.clients.put(gi.p2Num, 0);
				
				//set choices for these clients back to unknown
				gi.p1Play = "unknown";
				gi.p2Play = "unknown";
				
				//set both player nums to 0 so that server knows its a client status update
				gi.p1Num = 0;
				gi.p2Num = 0;
				
				//send to server to be sent to other players
				clientConnection.send(gi);
			}
			
			//set instructions back to default
			chooseController.challengeLabel.setText("click on a player to challenge them or wait to be challenged.");
			
			//set scene to gameplay scene
	    	Stage primaryStage = (Stage) playController.gameStatus.getScene().getWindow();
	    	primaryStage.setScene(chooseScene);
		});
		
		PauseTransition bothReady = new PauseTransition(Duration.seconds(0));
		bothReady.setOnFinished(event -> {
			
			//reveal the other players play
			playController.p1Image.setImage(new Image("/" + gi.p1Play + ".png".toString()));
			playController.p2Image.setImage(new Image("/" + gi.p2Play + ".png".toString()));
			
			//show the winner of the game
			if(!(gi.winner.equals("tie")))
			{
				playController.gameStatus.setText(gi.winner + " won!\nreturning to lobby...");
			}
			else
			{
				playController.gameStatus.setText("tie\nreturning to lobby...");
			}
			
			gameover.play();
			
		});	
		
		//consumer to handle updating the play scene with info from a passed gameinfo object
		Consumer<Serializable> playGuiUpdate = gameInfo -> Platform.runLater(()-> {
			
			gi = (GameInfo) gameInfo;
						
			//update gui items with all the information from the gameInfo object
			
			//set the player labels for each players number
			playController.p1NumLabel.setText("player " + gi.p1Num);
			playController.p2NumLabel.setText("player " + gi.p2Num);
			
			//prompt for a move and enable move buttons
			playController.gameStatus.setText("waiting for moves...");
			playController.rockImage.setDisable(false);
			playController.paperImage.setDisable(false);
			playController.scissorImage.setDisable(false);
			playController.lizardImage.setDisable(false);
			playController.spockImage.setDisable(false);
			
			if(clientConnection.myNumber == gi.p1Num) //if im player 1
			{
				//show my image
				playController.p1Image.setImage(new Image("/" + gi.p1Play + ".png"));
				
				//if both players have chosen, start game over sequence
				if(!(gi.p1Play.equals("unknown")) && !(gi.p2Play.equals("unknown")))
				{
					//playController.p2Image.setImage(new Image("/" + gi.p2Play + ".png"));
					
					//disable buttons while winner is shown
					playController.rockImage.setDisable(true);
					playController.paperImage.setDisable(true);
					playController.scissorImage.setDisable(true);
					playController.lizardImage.setDisable(true);
					playController.spockImage.setDisable(true);
					
					//show winner
					bothReady.play();
				}
				//otherwise show the unknown symbol
				else
				{
					playController.p2Image.setImage(new Image("/unknown.png"));
				}
				
			}
			else //if im player 2
			{
				//show my image
				playController.p2Image.setImage(new Image("/" + gi.p2Play + ".png"));
				
				//start win sequence if both players have chosen
				if(!(gi.p1Play.equals("unknown")) && !(gi.p2Play.equals("unknown")))
				{
					//playController.p1Image.setImage(new Image("/" + gi.p1Play + ".png"));
					
					//disable buttons while winner is shown
					playController.rockImage.setDisable(true);
					playController.paperImage.setDisable(true);
					playController.scissorImage.setDisable(true);
					playController.lizardImage.setDisable(true);
					playController.spockImage.setDisable(true);
					
					//show winner
					bothReady.play();
				}
				//otherwise show the unknown symbol
				else
				{
					playController.p1Image.setImage(new Image("/unknown.png"));
				}
			}
			
		});
		
		//consumer to handle updating the choose scene with info from a passed gameinfo object
		Consumer<Serializable> chooseGuiUpdate = gameInfo -> Platform.runLater(()-> {
			
			gi = (GameInfo) gameInfo;
			
			chooseController.playerNumLabel.setText("welcome, you're player " + Integer.toString(clientConnection.myNumber));
			
			//get the keys of the clients in the client status hashmap
			ArrayList<Integer> keys = new ArrayList<Integer>(gi.clients.keySet());
			
			//store the number of other players
			int numPlayers = 0;
			
			//clear the current client list
			chooseController.clientList.getItems().clear();
			
			//check all the client statuses and count the number that are connected still and the
			//number that are in a game
			for(int i = 0; i < keys.size(); i++)
			{
				int value = gi.clients.get(keys.get(i));
				
				//only add to board if its not you
				if(!(keys.get(i) == clientConnection.myNumber))
				{
					if(value == 0)
					{
						//add this client to the list view as waiting
						chooseController.clientList.getItems().add("player " + keys.get(i) + "   |   waiting for game");
						
						numPlayers++;
					}
					else if(value == -2)
					{
						//add this client to the list view as pending challenge
						chooseController.clientList.getItems().add("player " + keys.get(i) + "   |   pending challenge");
						
						numPlayers++;
					}
					else if(value > 0)
					{
						//add this client to the list view as in game
						chooseController.clientList.getItems().add("player " + keys.get(i) + "   |   in game against player " + value);
						
						numPlayers++;
					}
				}
			}
			
			//update the label telling player how many other players there are 
			if(numPlayers == 1) //singular
				chooseController.otherPlayerCountLabel.setText("there is " + numPlayers + " other player connected");
			else //plural
				chooseController.otherPlayerCountLabel.setText("there are " + numPlayers + " other players connected");
		
		});
		
		//consumer to disply pop up when client is challenged
		Consumer<Serializable> challenged = gameInfo -> Platform.runLater(() -> {
			
			gi = (GameInfo) gameInfo;
			
			//if challenge int is 1, then player was challenged
			if(gi.chal == 1)
			{
				//disable their list so they cant challenge anybody while being challenged
				chooseController.clientList.setDisable(true);
				
				//show the pop up
				chooseController.showPopup(gi.p1Num);
			}
			
			//if challenge int is 2, then challenge was accepted
			else if(gi.chal == 2)
			{
				//re enable list for challenging (after game is over)
				chooseController.clientList.setDisable(false);
				//update label to tell player challenge was accepted (for after game)
				chooseController.challengeLabel.setText("player " + gi.p2Num + " accepted your challenge!");
				
				//change scene to game scene
				Stage pStage = (Stage) chooseController.clientList.getScene().getWindow();
				pStage.setScene(playScene);
			}
			
			//if challenge int is 3, then challenge was declined
			else if(gi.chal == 3)
			{
				//re enable the list for challenging
				chooseController.clientList.setDisable(false);
				
				//update label to tell player that their challenge was declined
				chooseController.challengeLabel.setText("player " + gi.p2Num + " declined your challenge.");
			}
		});
		
		//consumer that implements run later for if the connection was successful
		Consumer<Serializable> success = data -> Platform.runLater(()-> {
			
			//notify user that the connection was successful
			errorLabel.setText("connected to server!");
			
			//move to the gameplay scene
			successfulConnect.play();
			
		});
		
		//consumer that implements runlater for if the connection failed
		Consumer<Serializable> fail = data -> Platform.runLater(()-> {
			
			//notify the user that the connection was not successful
			errorLabel.setText("could not connect to the server");
			
			//clear text fields and wait for user to retry or exit
			ipField.clear();
			portField.clear();
			
			//remove the error message
			failedConnect.play();
			
		});	
		
		//consumer to update server message list
		Consumer<String> listUpdate = message -> Platform.runLater(()-> {
			
			playController.serverMessageList.getItems().add(message);
			
		});
		
		try
		{
			//create a new connection
			clientConnection = new RPSLSClient(success, fail, playGuiUpdate, chooseGuiUpdate, challenged, listUpdate, ipField.getText(), Integer.parseInt(portField.getText()));
			
			//start the connection
			clientConnection.start();
		}
		catch(Exception e)
		{
			errorLabel.setText("please enter a valid ip and a valid port");
		}
		
    	 
	}
	
}