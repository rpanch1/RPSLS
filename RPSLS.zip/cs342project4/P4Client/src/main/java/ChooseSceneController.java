import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.util.function.Consumer;
import java.io.Serializable;

public class ChooseSceneController 
{
	RPSLSClient clientConnection;
	Scene inGameScene;
	Scene endScene;
	
	//controller so that the first scene controller can be accessed by other scenes
	ConnectSceneController connectController;
	
	//controller so that first scene controller can access second scene
	PlaySceneController playController;
	
	//consumer to update gui with a passed game info object
	Consumer<Serializable> guiUpdate;
	
	GameInfo gi;
	
	//retrieve the gui elements from client choose scene fxml file
	@FXML
	Label playerNumLabel;
	@FXML
	Label otherPlayerCountLabel;
	@FXML 
	ListView<String> clientList;
	@FXML
	Label addressLabel;
	@FXML
	Label challengeLabel;
    
	void showPopup(int challenger)
	{
		PopUp pu = new PopUp();
		pu.display(challenger);
	}
	
    @FXML public void handleListClick(MouseEvent me)
    {
		//get the number of the player you challenged
		String clicked = clientList.getSelectionModel().getSelectedItem();
		int num = Integer.parseInt(clicked.substring(0, 9).replaceAll("[^0-9]", ""));
		
    	
    	//System.out.println("clicked on: " + clientList.getSelectionModel().getSelectedItem());
    	//System.out.println("clicked on index: " + clientList.getSelectionModel().getSelectedIndex());
    	
		//create new gameinfo object to challenge player, starting with the most recent gi object the client received
    	GameInfo gi = connectController.clientConnection.gameInfo;
		
    	//System.out.println("i am client " + connectController.clientConnection.myNumber + " i just clicked client " + num + " their status is " + gi.clients.get(num));
    	
		if(gi.clients.get(num) == 0) //make sure the player youre challenging isnt in a game already
		{
	    	gi.chal = 1; //indicate were challenging another player
	    	gi.p1Num = connectController.clientConnection.myNumber; //challenger (my) number
	    	gi.p2Num = num; //challenged number
	    	
    		//set label to show that the challenge was successful
	    	challengeLabel.setText("you challenged player " + num + ". waiting for a response...");
	    	//disable the list so the player cant challenge somebody else while waiting for a response
	    	clientList.setDisable(true);
	    	
	    	//send object off to server to be sent to challenged client
	    	connectController.clientConnection.send(gi); 
		}
		else if(gi.clients.get(num) == -2) //they already have a pending challenge
		{
			challengeLabel.setText("you can't challenge player " + num + ", they have a pending challenge!");
		}
		else //they are in a game already
		{
			challengeLabel.setText("you can't challenge player " + num + ", they're already in a game!");
		}
	    	
    }
    
    class PopUp
    {
    	public void display(int challenger)
    	{
    		//create a new stage for the popup window
    		Stage popup = new Stage();
    		popup.setTitle("player " + connectController.clientConnection.myNumber);
    		popup.setMinWidth(250);
    		
    		//different elements of popup window. message prompting user, and an accept and decline button
    		Label challengeMessage = new Label("player " + Integer.toString(challenger) + " has challenged you!");
    		Button accept = new Button("accept");
    		Button decline = new Button("decline");
    		
    		//event handler for accept button
    		accept.setOnAction(e -> {
    			
    			//close the pop up
    			popup.close();
    			//re enable the list 
    			clientList.setDisable(false);
    			
    			//send the server a game info object informing them that player accepted challenge
    			GameInfo toUpdate = connectController.clientConnection.gameInfo;
    			toUpdate.chal = 2; //2 indicates accept
    			
    			//send to server to be sent to challenging player
    			connectController.clientConnection.send(toUpdate);
    			
    			//change scene to game scene
    			Stage pStage = (Stage) clientList.getScene().getWindow();
    			pStage.setScene(connectController.playScene);
    		});
    		
    		//event handler for decline button
    		decline.setOnAction(e -> {
    			
    			//send the server a gameinfo object to inform the other player you decline
    			GameInfo toUpdate = connectController.clientConnection.gameInfo;
    			toUpdate.chal = 3; //3 indicates decline
    			
    			//send the gameinfo object to the server to be sent to the client
    			connectController.clientConnection.send(toUpdate);
    			
    			//close the popup
    			popup.close();
    			//re enable the list
    			clientList.setDisable(false);
    		});
    		
    		//set up window layout
    		HBox Btns = new HBox(10, accept, decline);
    		Btns.setAlignment(Pos.CENTER);
    		VBox elmnts = new VBox(10, challengeMessage, Btns);
    		elmnts.setAlignment(Pos.CENTER);
    		
    		Scene popupScene = new Scene(elmnts, 250, 100);
    		popup.setScene(popupScene);
    		popup.showAndWait();
    		
    	}
    }
    
	
}
