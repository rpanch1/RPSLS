import java.io.Serializable;
import java.util.function.Consumer;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class PlaySceneController 
{
	RPSLSClient clientConnection;
	Scene inGameScene;
	Scene endScene;
	
	//controller so that the play scene controller can access connect scene controller
	ConnectSceneController connectController;
	
	//controller so that play scene can access choose screen controller
	ChooseSceneController chooseController;
	
	//consumer to update gui with a passed game info object
	Consumer<Serializable> guiUpdate;
	
	//ImageViews for each of the icons
	Image unknown = new Image("/unknown.png");
	Image notConnected = new Image("/notConnected.png");
	
	GameInfo gi;
	
	//retrieve elements from gameplay scene fxml file
    @FXML
    ImageView rockImage;
    @FXML
    ImageView paperImage;
    @FXML
    ImageView scissorImage;
    @FXML
    ImageView lizardImage;
    @FXML
    ImageView spockImage;
    @FXML
    ImageView p1Image;
    @FXML
    ImageView p2Image;
    @FXML
    ListView<String> serverMessageList;
    @FXML
    Label gameStatus;
    @FXML
    Label p1NumLabel;
    @FXML
    Label p2NumLabel;
    
    PlaySceneController()
    {    	
    }
    

	
	public void handleRockClick()
	{
		//System.out.println("rock clicked\n");
		
		//access the clientConnection created in the first scene
		RPSLSClient cc = connectController.clientConnection;
		
		//make a new instance of game info object to edit
		GameInfo gi = cc.gameInfo;
		
		//update game info based on which client clicked
		if(cc.myNumber == gi.p1Num)
		{
			gi.p1Play = "rock";
		}
		else if(cc.myNumber == gi.p2Num)
		{
			gi.p2Play = "rock";
		}
		
		//send the updated game info to the server
		cc.send(gi);
		
		//update clients own gui as well
		//guiUpdate.accept(gi);
	}
	
	public void handlePaperClick()
	{
		//System.out.println("paper clicked\n");
		
		//access the clientConnection created in the first scene
		RPSLSClient cc = connectController.clientConnection;
		
		//make a new instance of game info object to edit
		GameInfo gi = cc.gameInfo;
		
		//update game info based on which client clicked
		if(cc.myNumber == gi.p1Num)
		{
			gi.p1Play = "paper";
		}
		else if(cc.myNumber == gi.p2Num)
		{
			gi.p2Play = "paper";
		}
		
		//send the updated game info to the server
		cc.send(gi);
		
		//update clients own gui as well
		//guiUpdate.accept(gi);
	}
	
	public void handleScissorClick()
	{
		//System.out.println("scissor clicked\n");
		
		//access the clientConnection created in the first scene
		RPSLSClient cc = connectController.clientConnection;
		
		//make a new instance of game info object to edit
		GameInfo gi = cc.gameInfo;
		
		//update game info based on which client clicked
		if(cc.myNumber == gi.p1Num)
		{
			gi.p1Play = "scissors";
		}
		else if(cc.myNumber == gi.p2Num)
		{
			gi.p2Play = "scissors";
		}
		
		//send the updated game info to the server
		cc.send(gi);
		
		//update clients own gui as well
		//guiUpdate.accept(gi);
	}
	
	public void handleLizardClick()
	{
		//System.out.println("lizard clicked\n");
		
		//access the clientConnection created in the first scene
		RPSLSClient cc = connectController.clientConnection;
		
		//make a new instance of game info object to edit
		GameInfo gi = cc.gameInfo;
		
		//update game info based on which client clicked
		if(cc.myNumber == gi.p1Num)
		{
			gi.p1Play = "lizard";
		}
		else if(cc.myNumber == gi.p2Num)
		{
			gi.p2Play = "lizard";
		}
		
		//send the updated game info to the server
		cc.send(gi);
		
		//update clients own gui as well
		//guiUpdate.accept(gi);
	}
	
	public void handleSpockClick()
	{
		//System.out.println("spock clicked\n");
		
		//access the clientConnection created in the first scene
		RPSLSClient cc = connectController.clientConnection;
		
		//make a new instance of game info object to edit
		GameInfo gi = cc.gameInfo;
		
		//update game info based on which client clicked
		if(cc.myNumber == gi.p1Num)
		{
			gi.p1Play = "spock";
		}
		else if(cc.myNumber == gi.p2Num)
		{
			gi.p2Play = "spock";
		}
		
		//send the updated game info to the server
		cc.send(gi);
		
		//update clients own gui as well
		//guiUpdate.accept(gi);
	}
}
