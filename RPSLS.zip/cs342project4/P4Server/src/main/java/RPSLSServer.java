import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.function.Consumer;

public class RPSLSServer
{
	//hashmap that maps client id number to clientthread for that client
	HashMap<Integer, ClientThread> clients;
	
	//number of connected clients
	static int clientCount;
	
	//array list of client numbers that have been used but are now available
	static ArrayList<Integer> availableIDs;
	
	//instance of server
	static TheServer server;
	
	//hashmap holds the connected/ waiting/ ingame status for each client
	HashMap<Integer, Integer> clientInfo;
	
	//consumer to update the gui when the server starts successfully
	private Consumer<Serializable> success;
	
	//consumer to update the gui when the server starts unsuccessfully
	private Consumer<Serializable> fail;
	
	//consumer to update the server log when new events happen
	private Consumer<Serializable> guiUpdate;
	
	//consumer to update server log list in the gui with messages
	private Consumer<String> listUpdate;
	
	int portNumber;
	
	RPSLSServer(Consumer<Serializable> s, Consumer<Serializable> f, Consumer<Serializable> g, Consumer<String> l, int port)
	{
		clientCount = 0;
		clients = new HashMap<Integer, ClientThread>();
		clientInfo = new HashMap<Integer, Integer>();
		
		availableIDs = new ArrayList<Integer>();
		
		success = s;
		fail = f;
		guiUpdate = g;
		listUpdate = l;
		
		portNumber = port;
		
		server = new TheServer();
		server.start();
		
		//gameInfo = new GameInfo(0, 0, "notConnected", "notConnected", false, false);
	}
	
	void addToIDs(int num)
	{
		availableIDs.add(num);
	}
	
	public class TheServer extends Thread
	{
		
		public void run() 
		{
		
			try(ServerSocket mysocket = new ServerSocket(portNumber);)
			{
				//update gui for successful start
				success.accept(1);
				
				System.out.println("Server is waiting for a client!");
			
				while(true) 
				{	
					clientCount++;
					
					//figure out what number id this client will have. reuse an old one if there are any
					//if not, give it a new number that is the number of clients connected
					int numberToAssign;
					if(availableIDs.size() == 0)
					{
						numberToAssign = clientCount;
					}
					else
					{
						numberToAssign = availableIDs.get(0);
						availableIDs.remove(0);
					}
					
					//create a new client thread, add it to clients array list, and start the thread
					ClientThread c = new ClientThread(mysocket.accept(), numberToAssign);
					clients.put(numberToAssign, c);
					c.start();
					
					//add the client to the hashmap as connected and not in game
					clientInfo.put(numberToAssign, 0);
					
			    }
			}
			catch(Exception e) 
			{
				System.out.println("server socket did not launch");
			
				//update gui for failed server launch
				fail.accept(1);
			}
		}
	}
	

	class ClientThread extends Thread
	{
		Socket connection;
		int clientNum; //identifier for which client this is
		ObjectInputStream in;
		ObjectOutputStream out;
		
		ClientThread(Socket s, int clientNum)
		{
			this.connection = s;
			this.clientNum = clientNum;
		}
		
		//returns 0 if tie, 1 if player 1 won, and 2 if player 2 won
		//based on regular rock, paper, scissors, lizard, spock rules
		int determineWinner(String p1Play, String p2Play)
		{
			if(p1Play.equals("rock"))
			{
				if(p2Play.equals("rock"))
					return 0;
				else if(p2Play.equals("paper"))
					return 2;
				else if(p2Play.equals("scissors"))
					return 1;
				else if(p2Play.equals("lizard"))
					return 1;
				else
					return 2;
			}
			else if(p1Play.equals("paper"))
			{
				if(p2Play.equals("rock"))
					return 1;
				else if(p2Play.equals("paper"))
					return 0;
				else if(p2Play.equals("scissors"))
					return 2;
				else if(p2Play.equals("lizard"))
					return 2;
				else
					return 1;
			}
			else if(p1Play.equals("scissors"))
			{
				if(p2Play.equals("rock"))
					return 2;
				else if(p2Play.equals("paper"))
					return 1;
				else if(p2Play.equals("scissors"))
					return 0;
				else if(p2Play.equals("lizard"))
					return 1;
				else
					return 2;
			}
			else if(p1Play.equals("lizard"))
			{
				if(p2Play.equals("rock"))
					return 2;
				else if(p2Play.equals("paper"))
					return 1;
				else if(p2Play.equals("scissors"))
					return 2;
				else if(p2Play.equals("lizard"))
					return 0;
				else
					return 1;
			}
			else 
			{
				if(p2Play.equals("rock"))
					return 1;
				else if(p2Play.equals("paper"))
					return 2;
				else if(p2Play.equals("scissors"))
					return 1;
				else if(p2Play.equals("lizard"))
					return 2;
				else
					return 0;
			}
		}
		
		//sends gameinfo object gi to all connected clients
		void sendToAll(GameInfo gi)
		{
			
			//list of keys in clientInfo
			ArrayList<Integer> keys = new ArrayList<Integer>(gi.clients.keySet());
			
			//iterate through all keys and send object to connected clients
			for(int i = 0; i < keys.size(); i++)
			{
				//get the client thread for this client
				ClientThread t = clients.get(keys.get(i));
				
				if(gi.clients.get(keys.get(i)) >= 0)
				{
					try
					{
						t.out.writeObject(gi);
						t.out.reset();
					}
					catch(Exception e)
					{
						System.out.println("failed to update client: " + keys.get(i));
					}
				}
			}
		}
		
		//only send passed gameinfo to clients that aren't in a game
		void sendToWaiting(GameInfo gi)
		{
			//list of keys in clientInfo
			ArrayList<Integer> keys = new ArrayList<Integer>(gi.clients.keySet());
			
			//iterate through all keys and send object to connected clients
			for(int i = 0; i < keys.size(); i++)
			{
				//get the client thread for this client
				ClientThread t = clients.get(keys.get(i));
				
				if(gi.clients.get(keys.get(i)) == 0)
				{
					try
					{
						t.out.writeObject(gi);
						t.out.reset();
					}
					catch(Exception e)
					{
						System.out.println("failed to update client: " + keys.get(i));
					}
				}
			}
		}
		
		public void run()
		{	
			try 
			{
				in = new ObjectInputStream(connection.getInputStream());
				out = new ObjectOutputStream(connection.getOutputStream());
				connection.setTcpNoDelay(true);	
			}
			catch(Exception e) 
			{
				System.out.println("Streams not open");
			}
			
			synchronized(clients)
			{
				//record that this client connected in server log
				listUpdate.accept("client " + clientNum + " connected");
				
				//create an initial game info object to send to client and update
				GameInfo gi = new GameInfo(clientInfo, -5, clientNum, "unknown", "unknown", false);
				guiUpdate.accept(gi); //update server gui
				
				//send object to client
				try
				{	
					this.out.writeObject(gi);
					this.out.reset();
					
					//set nums back to 0 then send object to all clients so they can update their list
					gi.p1Num = 0;
					gi.p2Num = 0;
					//gi.clients.put(clientNum, 0);
					gi.clients = clientInfo;
					
					//sendToAll(gi);
					sendToWaiting(gi);
				}
				catch(Exception e2)
				{
					System.out.println("error performing initial write to object 1: " + e2);
				}
			}
			
			while(true) 
			{
				try
				{	
					//read in from client
					GameInfo gi = (GameInfo) in.readObject();
					
					synchronized(clients)
					{	
						//if both player numbers are 0, its simply a client status update for other clients
						if(gi.p1Num == 0 && gi.p2Num == 0)
						{
							//update the gameinfo with the servers most recent game info
							gi.clients = clientInfo;
							
							//sendToAll(gi); //update all clients lists
							sendToWaiting(gi);
							guiUpdate.accept(gi); //update server list
						}
						
						//if chal int is set to 1, facilitate the challenge
						else if(gi.chal == 1)
						{
							//log the challenge in the server
							listUpdate.accept("player " + gi.p1Num + " challenged player " + gi.p2Num);
							
							//inform challenged player that they were challenged
							try
							{
								//send the received object to the challenged player
								clients.get(gi.p2Num).out.writeObject(gi);
								clients.get(gi.p2Num).out.reset();
								
							}
							catch(Exception e)
							{
								System.out.println("error sending object to challenged client " + gi.p2Num + ": " + e);
							}
							
							//update the client info hashmap to reflect the pending challenge
							clientInfo.put(gi.p2Num, -2);
							clientInfo.put(gi.p1Num, -2);
							
							//also update gi with this information so it can be conveniently sent to all clients to inform them
							gi.clients.put(gi.p2Num, -2);
							gi.clients.put(gi.p1Num, -2);
							gi.chal = 0;
							gi.p2Num = 0;
							gi.p1Num = 0;
							sendToWaiting(gi); //send game info with updated client info so other clients can show these players in game
							
							//also update server gui with this info
							guiUpdate.accept(gi);
						}
						
						//if chal int is 2, the inform challenger that their challenge was accepted
						else if(gi.chal == 2)
						{
							//store the player numbers for later use
							int player1Number = gi.p1Num;
							int player2Number = gi.p2Num;
							
							//log the challenge accept in the server
							listUpdate.accept("player " + gi.p2Num + " accepted the challenge from player " + gi.p1Num);
							listUpdate.accept("players " + gi.p1Num + " and " + gi.p2Num + " are now in a game");
							
							try
							{
								//send the recieved object back to the challenger to inform them of accept
								clients.get(gi.p1Num).out.writeObject(gi);
								clients.get(gi.p1Num).out.reset();
							}
							catch(Exception e)
							{
								System.out.println("error informing " + gi.p1Num + " that their challenge was accepted " + e);
							}
							
							//update the client info hashmap to reflect the players are now in a game
							clientInfo.put(gi.p1Num, gi.p2Num);
							clientInfo.put(gi.p2Num, gi.p1Num);
							
							//also update gi with this information so it can be conveniently sent to all clients to inform them
							gi.clients.put(gi.p1Num, gi.p2Num);
							gi.clients.put(gi.p2Num, gi.p1Num);
							gi.chal = 0;
							gi.p2Num = 0;
							gi.p1Num = 0;
							sendToWaiting(gi);
							
							//also update server gui with this info
							guiUpdate.accept(gi);
							
							//create game info object representing a fresh game before values are changed
							GameInfo gameStart = new GameInfo(gi.clients, player1Number, player2Number, "unknown", "unknown", false);
							
							//send the GameInfo object with game start info to the clients that are playing
							try 
							{
								clients.get(gameStart.p1Num).out.writeObject(gameStart);
								clients.get(gameStart.p1Num).out.reset();
							}
							catch(Exception e)
							{
								System.out.println("error sending fresh game contents to client " + gameStart.p1Num + e);
							}
							try //try sending to second client
							{
								clients.get(gameStart.p2Num).out.writeObject(gameStart);
								clients.get(gameStart.p2Num).out.reset();
							}
							catch(Exception e)
							{
								System.out.println("error sending fresh game contents to client " + gameStart.p2Num + e);
							}
						}
						else if(gi.chal == 3)
						{
							//log the challenge decline in the server
							listUpdate.accept("player " + gi.p2Num + " declined the challenge from player " + gi.p1Num);
							
							//update in the client info hashmap that the clients are no longer being challenged
							clientInfo.put(gi.p1Num, 0);
							clientInfo.put(gi.p2Num, 0);
							
							//update server gui to show that challenge was declined
							guiUpdate.accept(gi);
							
							try
							{
								//send the recieved object back to the challenger to inform them of decline
								clients.get(gi.p1Num).out.writeObject(gi);
								clients.get(gi.p1Num).out.reset();
								
								//send to other clients so they also know challenge was declined
								gi.p1Num = 0; //reset these variables to 0 so that clients know its just a gui update
								gi.p2Num = 0;
								gi.chal = 0;
								sendToWaiting(gi);
							}
							catch(Exception e)
							{
								System.out.println("error informing " + gi.p1Num + " that their challenge was declined " + e);
							}
						}
						
						//if challenge is 0 then the incoming game info is about a game in progress
						else if(gi.p1Num == clientNum || gi.p2Num == clientNum) //make sure game info came a client in my game
						{
							
							//if both players have made a choice, then choose a winner
							if(!(gi.p1Play.equals("unknown")) && !(gi.p2Play.equals("unknown")))
							{
								//determine who won
								int winner = determineWinner(gi.p1Play, gi.p2Play);
								if(winner == 0) gi.winner = "tie";
								else if(winner == 1) gi.winner = "player " + Integer.toString(gi.p1Num);
								else gi.winner = "player " + Integer.toString(gi.p2Num);
								
								//update the server log with win
								if(winner == 1)
									listUpdate.accept("player " + gi.p1Num + " (" + gi.p1Play + ") beat player " + gi.p2Num + " (" + gi.p2Play + ")");
								else if(winner == 2)
									listUpdate.accept("player " + gi.p2Num + " (" + gi.p2Play + ") beat player " + gi.p1Num + " (" + gi.p1Play + ")");
								else
									listUpdate.accept("player " + gi.p1Num + " (" + gi.p1Play + ") tied with player " + gi.p2Num + " (" + gi.p2Play + ")");
								
								//update client statuses to no longer be in game
								clientInfo.put(gi.p1Num, 0);
								clientInfo.put(gi.p2Num, 0);
								
								//send game info with winner back to clients
								try //send to p1
								{
									clients.get(gi.p1Num).out.writeObject(gi);
									clients.get(gi.p1Num).out.reset();
								}
								catch(Exception e)
								{
									System.out.println("could not send object to player 1: " + e);
								}
								try //send to p2
								{
									clients.get(gi.p2Num).out.writeObject(gi);
									clients.get(gi.p2Num).out.reset();
								}
								catch(Exception e)
								{
									System.out.println("could not send object to player 2: " + e);
								}
							}
							else
							{
								try //send to p1
								{
									clients.get(gi.p1Num).out.writeObject(gi);
									clients.get(gi.p1Num).out.reset();
								}
								catch(Exception e)
								{
									System.out.println("could not send object to player 1: " + e);
								}
								try //send to p2
								{
									clients.get(gi.p2Num).out.writeObject(gi);
									clients.get(gi.p2Num).out.reset();
								}
								catch(Exception e)
								{
									System.out.println("could not send object to player 2: " + e);
								}
							}
						}
						
					}
					
				}
				catch(Exception e)
				{
					//update server log to say client disconnected
					listUpdate.accept("client " + clientNum + " disconnected");
					
					//update the clientinfo hashmap to reflect that client disconnected
					clientInfo.put(clientNum, -1);
					
					//create a dummy gameinfo to send clientinfo to update the gui with
					GameInfo toUpdate = new GameInfo(clientInfo, 0, 0, "unknown", "unknown", false);
					guiUpdate.accept(toUpdate);
					
					//send to clients so they can update their client list
					sendToWaiting(toUpdate);
					
					//add the clients id number to the array list so it can be reused
					addToIDs(clientNum);
					break;
				}
			}
		}
	}
}


	
	

	
